console.log('Привет, мир!')
