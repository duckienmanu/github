'use strict'
const exercise = require('workshopper-exercise/basic')

module.exports = exercise
